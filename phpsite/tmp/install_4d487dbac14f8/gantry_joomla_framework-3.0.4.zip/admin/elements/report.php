<?php
/**
 * @package     gantry
 * @subpackage  admin.elements
 * @version		3.0.4 July 1, 2010
 * @author		RocketTheme http://www.rockettheme.com
 * @copyright 	Copyright (C) 2007 - 2010 RocketTheme, LLC
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 * Gantry uses the Joomla Framework (http://www.joomla.org), a GNU/GPLv2 content management system
 *
 */
defined('JPATH_BASE') or die();
/**
 * @package     gantry
 * @subpackage  admin.elements
 */
class JElementReport extends JElement {
	

	function fetchElement($name, $value, &$node, $control_name)
	{
		global $gantry;
		
		$output = "";

        // get params.ini
        // get gantry dir permissions
        // get gantry config file
        // get mismatched md5sums
        // get contents of non default template/gantry files
        
        

        // get system info
        // get joomla dir permissions
        // get joomla config file


	}
}
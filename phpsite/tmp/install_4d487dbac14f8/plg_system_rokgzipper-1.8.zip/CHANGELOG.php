<?php
/**
 * RokGZipper Plugin
 *
 * @package RocketTheme
 * @subpackage rokgzipper
 * @version   1.8 January 30, 2010
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2010 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 */
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

1. Copyright and disclaimer
----------------


2. Changelog
------------
This is a non-exhaustive changelog for RokGZipper, inclusive of any alpha, beta, release candidate and final versions.

Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

----------- 1.8 Release (30-Jan-2010)-----------

30-Jan-2010 Andy Miller
# Fixed handling of single files when JS folder is unwritable

----------- 1.7 Release (01-Jan-2010)-----------

01-Jan-2010 Brian Towles
+ add support to ignore gantry files that are already gzipped

----------- 1.6 Release (30-Nov-2009)-----------

30-Nov-2009 Brian Towles
+ Added css whitespace and comment stripping
# Fixed cleanup of query strings from css files

----------- 1.5 Release (31-Oct-2009)-----------

31-Oct-2009 Brian Towles
# Fixed reversal of CSS issue

----------- 1.4 Release (29-Oct-2009)-----------

29-Oct-2009 Brian Towles
# Fixed backwards compatibility with regexp

----------- 1.3 Release (07-Sep-2009)-----------

7-Sep-2009 Brian Towles
# Fixed ignore issue caused by extra DS

4-Sep-2009 Brian Towles
^ Moved from Document link/script to scanning body for all links/scripts
+ Added ignore of file option
+ Added cache file contents comments option
+ Added writeable directory checks and comment warnings.

----------- 1.2 Release -----------

# Removed path from comments

----------- 1.1 Release -----------

# Minor bug fixes
 
----------- 1.0 Release -----------

+ Initial Release
<?php
/**
 * RocketTheme Module
 *
 * @package RocketTheme
 * @subpackage rokmodule.admin
 * @version   1.2 April 12, 2010
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2010 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 */
defined('_JEXEC') or die();
/**
 * @package RocketTheme
 * @subpackage rokmodule.admin
 */
class HTML_RokModule
{
	
}


?>
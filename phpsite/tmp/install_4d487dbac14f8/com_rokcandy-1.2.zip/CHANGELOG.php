<?php
/**
 * @version		$Id: CHANGELOG.php 3381 2008-02-02 13:41:29Z rhuk $ 
 * @package RokCandy
 * @copyright Copyright (C) 2007 RocketTheme. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * @author RocketTheme, LLC
 */
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

1. Copyright and disclaimer
---------------------------


2. Changelog
------------
This is a non-exhaustive changelog for RokCandy, inclusive of any alpha, beta, release candidate and final versions.

Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

----------- 1.2 Released -----------------

04/27/10 Brian Towles
# Fixed for self closing tags

----------- 1.1 Released -----------------

03/06/10 Brian Towles
# Fixed segfault for early non unicode PCRE libraries. 

----------- 1.0 Released -----------------

02/04/10 Brian Towles
# Fixed issue with missing macros should fail quiet now
# Fixed bad tokens

----------- 0.88a Released -----------------

11/06/09 Brian Towles
# Changed the newline handling for regular expressions.

----------- 0.87a Released -----------------

10/29/09 Brian Towles
# Fixed some backwards compat regular expressions 


----------- 0.86a Released -----------------

10/06/09 Brian Towles
# Added better javascript handleing to fix issues with Community Builder and more. 

----------- 0.85a Released -----------------

08/19/09 Brian Towles
# Fixed to search for nested instances of tags to prevent javascript expansion
# Fixed non-default value for argument for onPrepareContent
# Fixed bug in disabled overrides

----------- 0.84a Released -----------------

06/11/09 Andy Miller
+ Fixed problem with error on PDF view

----------- 0.83a Released -----------------

04/16/09 Andy Miller
+ Added onPrepareContent Trigger for rokcandy in content items

----------- 0.82a Released -----------------

02/02/09 Andy Miller
+ Added Frontend editor button support
+ Added custom disable ability, ie for community builder profiles
# Fixed filtering of certain HTML tags (eg script, iframe, etc)
# Fixed ability to leave macro variables empty between quotes

----------- 0.81a Released -----------------

02/02/09 Andy Miller
# Added PHP4 compatibility fix

----------- 0.8a Released -----------------

01/28/09 Andy Miller
+ Initial Release


 

 


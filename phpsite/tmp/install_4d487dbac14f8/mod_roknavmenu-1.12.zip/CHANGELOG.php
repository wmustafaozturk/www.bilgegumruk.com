<?php
/**
 * RokNavMenu Plugin
 *
 * @package		Joomla
 * @subpackage	RokNavMenu Plugin
 * @copyright Copyright (C) 2009 RocketTheme. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see RT-LICENSE.php
 * @author RocketTheme, LLC
 *
 */
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

1. Copyright and disclaimer
----------------


2. Changelog
------------
This is a non-exhaustive changelog for RokNavMenu, inclusive of any alpha, beta, release candidate and final versions.

Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

------- 1.11 Release [29-March-2010] -------
30-March-2010 Brian Towles
# Fix for centered dropdowns

------- 1.10 Release [26-March-2010] -------
26-March-2010 Brian Towles
# Fix for cache with multiple instances

------- 1.9 Release [24-March-2010] -------
24-March-2010 Brian Towles
# Fix for cache under php 5.3

------- 1.8 Release [16-March-2010] -------
13-March-2010 Brian Towles
# Fix for url type

------- 1.7.14 Release [28-February-2010] -------

24-Feb-2010 Djamil Legato
# Dropdowns fusion container now inherits all the classes from the parent element

------- 1.7.13 Release [30-January-2010] -------

26-Jan-2010 Brian Towles
# Fixed child level issue
# Fixed typo in Fusion layout.php

------- 1.7.12 Release [09-January-2010] -------

09-Jan-2010 Djamil Legato
# Fixed centered dropdowns in RTL mode

------- 1.7.11 Release [06-January-2010] -------

06-Jan-2010 Brian Towles
# Fixed bug in SSL url handling

------- 1.7.10 Release [04-January-2009] -------

03-Jan-2009 Djamil Legato
# Fixed a typo that wasn't cleaning the dropdowns when closed.


------- 1.7.9 Release [30-December-2009] -------

30-Dec-2009 Djamil Legato
+ Added full RTL support

------- 1.7.8 Release [11-December-2009] -------

11-Dec-2009 Djamil Legato
# Backward compatibility fix

NOTE: DO NOT USE THIS VERSION WITH NEXUS TEMPLATE

------- 1.7.7 Release [08-December-2009] -------

08-Dec-2009 Djamil Legato
# Fixed 'ghosts' submenus that didn't let click on the page in some circumstances

------- 1.7.6 Release [26-November-2009] -------

26-Nov-2009 Djamil Legato
+ Added centering option for having the dropdowns center aligning to the root item

------- 1.7.5 Release [30-August-2009] -------

30-Aug-2009 Andy Miller
# Updated CSS and created IE6 CSS for new fusion.js format

29-Aug-2009 Brian Towles
# Fixed child menus showing up at the wrong time when not showing all links


28-Aug-2009 Brian Towles
# Fixed menulinks to honor their own params and not show as active
# Fixed extended link query string creation on SEO and not.

------- 1.7.4 Release [19-August-2009] -------

19-Aug-2009 Brian Towles
# Fixed handling of HTML Special characters in menu item titles.
^ Moved to namespaced events to help prevent collisions with other extensions.
# Fixed handling of no parameter menu items. 

------- 1.7.3 Release [14-August-2009] -------

14-Aug-2009 Brian Towles
# Fixed bug with backwards compatibility with older templates

07-Aug-2009 Brian Towles
# Fixed bug in fusion theme not calling getLink in the layout

------- 1.7.2 Release [07-August-2009] -------

06-Aug-2009 Brian Towles
# Fixed Multiple instances resulting in fatal error
^ Moved Formatting classes to be Named based on Default/Template and theme name
# Fixed issue with multiple roknavmenu instances with different themes causing crashes
+ Added link additions to the node type
+ Added extended link plugin to let menu item use of link additions 

06-Aug-2009 Djamil Legato
# Fixed javascript error when no sublevels present

------- 1.7.1 Release [01-August-2009] -------

01-Aug-2009 Brian Towles
# Fixed php4 compatibility with class_exists

31-July-2009 Brian Towles
+ Added i18n language support for modules theme parameters
+ Added i18n language support for boost menu item parameters 

------- 1.7 Release [31-July-2009] -------

+ New component based installation/uninstallation
+ Added RokNavMenu Theme support for module and templates
+ Added "Boost" plugin to allow overriding of menu items
+ Added NEW Fusion theme


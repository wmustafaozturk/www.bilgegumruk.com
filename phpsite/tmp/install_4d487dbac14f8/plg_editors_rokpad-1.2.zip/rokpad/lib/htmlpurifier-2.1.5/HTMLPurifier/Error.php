<?php

/**
 * Return object from functions that signifies error when null doesn't cut it
 */
class HTMLPurifier_Error {}

